% obtain EMG data
n = length(emg);
signal = emg;%EMG data 
 % proportion of time points to replace with noise
propnoise = .05; % 5 percent of data will be replaced with spikes
 % find noise points randomely selected
noisepnts = randperm(n);
noisepnts = noisepnts(1:round(n*propnoise));
% generate signal and replace points with noise
signal(noisepnts) = 500+rand(size(noisepnts))*100;
% use hist to pick threshold
figure(1), clf
histogram(signal,1000)
zoom on
% visual-picked threshold
threshold = 500;
% find data values above the threshold
suprathresh = find( signal>threshold );
% initialize filtered signal
filtsig = signal;
% loop through suprathreshold points and set to median of k
k = 10; % actual window is k*2+1
for ti=1:length(suprathresh)
 % find lower and upper bounds
 lowbnd = max(1,suprathresh(ti)-k);
 uppbnd = min(suprathresh(ti)+k,n);

 % compute median of surrounding points
 filtsig(suprathresh(ti)) = median(signal(lowbnd:uppbnd));
end
% plot
figure(2), clf
plot(1:n,signal, 1:n,filtsig, 'linew',2)
zoom on
