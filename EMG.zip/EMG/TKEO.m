% import data
load emg4TKEO.mat

% initialize filtered signal
emgf = emg;
% the loop version for interpretability
for i=2:length(emgf)-1
 emgf(i) = emg(i)^2 - emg(i-1)*emg(i+1);
end
%% plot
figure(1), clf
% plot "raw" (normalized to max-1)try this code without normalization. 
hold on
plot(emgtime,emg./max(emg),'b','linew',2)

plot(emgtime,emgf./max(emgf),'m','linew',2)
xlabel('Time (ms)'), ylabel('Amplitude or energy')
legend({'EMG';'EMG energy (TKEO)'})
